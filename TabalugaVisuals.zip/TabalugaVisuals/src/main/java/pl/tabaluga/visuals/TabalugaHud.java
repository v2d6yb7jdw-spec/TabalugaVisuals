package pl.tabaluga.visuals;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.text.Text;

/** Client-only HUD overlays. All elements are cosmetic and local to the player. */
public final class TabalugaHud {
    private static final int WHITE = 0xFFFFFFFF;
    private static final int ACCENT = 0xFFA66BFF;
    private static final int PANEL = 0xC9161925;

    private TabalugaHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.options.hudHidden) return;
        TabalugaConfig cfg = TabalugaConfig.get();
        int sw = context.getScaledWindowWidth();
        int sh = context.getScaledWindowHeight();
        int cx = sw / 2;
        int cy = sh / 2;

        if (cfg.showWatermark) {
            context.fill(8, 8, 139, 29, PANEL);
            context.fill(8, 8, 11, 29, ACCENT);
            context.drawText(client.textRenderer, "TabalugaVisuals 0.1", 16, 14, WHITE, false);
        }

        if (cfg.customCrosshair) drawCrosshair(context, cx, cy, cfg);
        if (cfg.hitMarker && CombatVisuals.getHitMarkerTicks() > 0) drawHitMarker(context, cx, cy);
        if (cfg.damageNumbers && CombatVisuals.getDamageTicks() > 0) {
            String damage = String.format(java.util.Locale.ROOT, "-%.1f", CombatVisuals.getLastDamage());
            context.drawCenteredTextWithShadow(client.textRenderer, damage, cx, cy + 15, 0xFFFF7777);
        }
        if (cfg.comboCounter && CombatVisuals.getCombo() > 1) {
            context.drawCenteredTextWithShadow(client.textRenderer, "COMBO x" + CombatVisuals.getCombo(), cx, cy + 31, ACCENT);
        }
        if (cfg.targetHud) drawTargetHud(context, client);
        if (cfg.cooldownRing) drawCooldownRing(context, client, cx, cy, cfg);
    }

    private static void drawCrosshair(DrawContext ctx, int x, int y, TabalugaConfig cfg) {
        int size = Math.max(3, Math.min(14, cfg.crosshairSize));
        int gap = Math.max(1, Math.min(8, cfg.crosshairGap));
        int color = WHITE;
        MinecraftClient client = MinecraftClient.getInstance();
        if (cfg.crosshairTargetColor && isAimingAtLivingEntity(client)) {
            color = 0xFFFF3030;
        }
        switch (cfg.crosshairStyle) {
            case "Dot" -> ctx.fill(x - 1, y - 1, x + 2, y + 2, color);
            case "Circle" -> {
                ctx.fill(x - size, y - size, x + size + 1, y - size + 2, color);
                ctx.fill(x - size, y + size - 1, x + size + 1, y + size + 1, color);
                ctx.fill(x - size, y - size, x - size + 2, y + size + 1, color);
                ctx.fill(x + size - 1, y - size, x + size + 1, y + size + 1, color);
            }
            default -> {
                ctx.fill(x - size, y - 1, x - gap, y + 1, color);
                ctx.fill(x + gap + 1, y - 1, x + size + 1, y + 1, color);
                ctx.fill(x - 1, y - size, x + 1, y - gap, color);
                ctx.fill(x - 1, y + gap + 1, x + 1, y + size + 1, color);
            }
        }
    }

    private static boolean isAimingAtLivingEntity(MinecraftClient client) {
        if (client.player == null || !(client.crosshairTarget instanceof EntityHitResult hit)) return false;
        Entity entity = hit.getEntity();
        return entity instanceof LivingEntity living
                && entity != client.player
                && living.isAlive()
                && !living.isRemoved();
    }

    private static void drawHitMarker(DrawContext ctx, int x, int y) {
        int c = WHITE;
        ctx.fill(x - 5, y - 5, x - 2, y - 2, c);
        ctx.fill(x + 2, y - 5, x + 5, y - 2, c);
        ctx.fill(x - 5, y + 2, x - 2, y + 5, c);
        ctx.fill(x + 2, y + 2, x + 5, y + 5, c);
    }

    private static void drawTargetHud(DrawContext ctx, MinecraftClient client) {
        LivingEntity target = CombatVisuals.getCurrentTarget();
        if (target == null || target.isRemoved() || target.isDead()) return;
        int x = 10, y = 43, w = 142, h = 43;
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y, x + 3, y + h, ACCENT);
        ctx.drawText(client.textRenderer, target.getName().getString(), x + 9, y + 6, WHITE, false);
        float max = Math.max(1.0f, target.getMaxHealth());
        float health = Math.max(0.0f, Math.min(1.0f, target.getHealth() / max));
        ctx.fill(x + 9, y + 23, x + w - 9, y + 29, 0xFF454454);
        ctx.fill(x + 9, y + 23, x + 9 + (int)((w - 18) * health), y + 29, 0xFFB66CFF);
        ctx.drawText(client.textRenderer, String.format(java.util.Locale.ROOT, "%.1f / %.1f HP", target.getHealth(), max), x + 9, y + 32, 0xFFD7D4E2, false);
    }

    private static void drawCooldownRing(DrawContext ctx, MinecraftClient client, int x, int y, TabalugaConfig cfg) {
        float progress = client.player.getAttackCooldownProgress(0.0f);
        int radius = 13;
        int segments = Math.max(1, Math.round(progress * 16));
        for (int i = 0; i < 16; i++) {
            double angle = (Math.PI * 2.0 * i / 16.0) - Math.PI / 2.0;
            int px = x + (int)Math.round(Math.cos(angle) * radius);
            int py = y + (int)Math.round(Math.sin(angle) * radius);
            int color = i < segments ? ACCENT : 0x88777788;
            ctx.fill(px - 1, py - 1, px + 2, py + 2, color);
        }
    }
}
