package pl.tabaluga.visuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Lightweight click GUI. Left click toggles options; right click cycles selectable values. */
public final class TabalugaClickGui extends Screen {
    private static final int PANEL = 0xE8171924;
    private static final int HEADER = 0xFF24283A;
    private static final int ACCENT = 0xFFA66BFF;
    private static final int TEXT = 0xFFF3F1FA;
    private static final int MUTED = 0xFFAAA8B8;
    private static final String[] EFFECTS = {"Galaxy", "Flame", "Hearts", "Soul", "Portal", "Ice", "Totem", "Classic"};
    private static final String[] CROSSHAIRS = {"Plus", "Dot", "Circle"};
    private static final String[] PRESETS = {"Default", "PvP", "Minimal"};

    public TabalugaClickGui() { super(Text.literal("TabalugaVisuals")); }

    private int left() { return (width - 520) / 2; }
    private int top() { return (height - 408) / 2; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int l = left(), t = top(), r = l + 520, b = t + 408;
        TabalugaConfig c = TabalugaConfig.get();
        ctx.fill(l, t, r, b, PANEL);
        ctx.fill(l, t, r, t + 39, HEADER);
        ctx.fill(l, t, l + 4, b, ACCENT);
        ctx.drawText(textRenderer, "TABALUGA", l + 17, t + 11, TEXT, false);
        ctx.drawText(textRenderer, "VISUALS 0.1", l + 112, t + 11, ACCENT, false);
        ctx.drawText(textRenderer, "RIGHT SHIFT / ESC - CLOSE", r - 174, t + 13, MUTED, false);

        section(ctx, l + 18, t + 54, "COMBAT");
        row(ctx, l + 18, t + 76, "Hit Particles", c.hitParticles);
        row(ctx, l + 18, t + 98, "Kill Effects", c.killEffects);
        valueRow(ctx, l + 18, t + 120, "Kill Effect", c.killEffect);
        row(ctx, l + 18, t + 142, "Hit Marker", c.hitMarker);
        row(ctx, l + 18, t + 164, "Damage Numbers", c.damageNumbers);
        row(ctx, l + 18, t + 186, "Combo Counter", c.comboCounter);

        section(ctx, l + 270, t + 54, "HUD & CROSSHAIR");
        row(ctx, l + 270, t + 76, "Watermark", c.showWatermark);
        row(ctx, l + 270, t + 98, "Target HUD", c.targetHud);
        row(ctx, l + 270, t + 120, "Cooldown Ring", c.cooldownRing);
        row(ctx, l + 270, t + 142, "Custom Crosshair", c.customCrosshair);
        valueRow(ctx, l + 270, t + 164, "Crosshair Style", c.crosshairStyle);
        row(ctx, l + 270, t + 186, "White > Red on target", c.crosshairTargetColor);

        section(ctx, l + 18, t + 232, "CLIENT");
        row(ctx, l + 18, t + 254, "Performance Mode", c.performanceMode);
        valueRow(ctx, l + 18, t + 276, "Preset", c.activePreset);
        ctx.drawText(textRenderer, "Presets: Default / PvP / Minimal", l + 18, t + 310, MUTED, false);
        ctx.fill(l + 18, t + 337, r - 18, t + 338, 0x554C5065);
        ctx.drawText(textRenderer, "Settings save automatically to config/tabalugavisuals.json", l + 18, t + 352, MUTED, false);
        ctx.drawText(textRenderer, "LMB: toggle     RMB: cycle value", l + 18, t + 373, ACCENT, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void section(DrawContext ctx, int x, int y, String title) {
        ctx.drawText(textRenderer, title, x, y, ACCENT, false);
    }

    private void row(DrawContext ctx, int x, int y, String label, boolean enabled) {
        ctx.drawText(textRenderer, label, x, y, TEXT, false);
        String state = enabled ? "ON" : "OFF";
        ctx.drawText(textRenderer, state, x + 205, y, enabled ? 0xFF8FE3A0 : 0xFFFF8585, false);
    }

    private void valueRow(DrawContext ctx, int x, int y, String label, String value) {
        ctx.drawText(textRenderer, label, x, y, TEXT, false);
        ctx.drawText(textRenderer, "< " + value + " >", x + 125, y, 0xFFD7C2FF, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 && button != 1) return super.mouseClicked(mouseX, mouseY, button);
        int l = left(), t = top();
        TabalugaConfig c = TabalugaConfig.get();
        boolean changed = false;

        if (inRow(mouseX, mouseY, l + 18, t + 76)) { c.hitParticles = !c.hitParticles; changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 98)) { c.killEffects = !c.killEffects; changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 120) && button == 1) { c.killEffect = cycle(EFFECTS, c.killEffect); changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 142)) { c.hitMarker = !c.hitMarker; changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 164)) { c.damageNumbers = !c.damageNumbers; changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 186)) { c.comboCounter = !c.comboCounter; changed = true; }
        else if (inRow(mouseX, mouseY, l + 270, t + 76)) { c.showWatermark = !c.showWatermark; changed = true; }
        else if (inRow(mouseX, mouseY, l + 270, t + 98)) { c.targetHud = !c.targetHud; changed = true; }
        else if (inRow(mouseX, mouseY, l + 270, t + 120)) { c.cooldownRing = !c.cooldownRing; changed = true; }
        else if (inRow(mouseX, mouseY, l + 270, t + 142)) { c.customCrosshair = !c.customCrosshair; changed = true; }
        else if (inRow(mouseX, mouseY, l + 270, t + 164) && button == 1) { c.crosshairStyle = cycle(CROSSHAIRS, c.crosshairStyle); changed = true; }
        else if (inRow(mouseX, mouseY, l + 270, t + 186)) { c.crosshairTargetColor = !c.crosshairTargetColor; changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 254)) { c.performanceMode = !c.performanceMode; changed = true; }
        else if (inRow(mouseX, mouseY, l + 18, t + 276) && button == 1) { TabalugaConfig.applyPreset(cycle(PRESETS, c.activePreset)); changed = true; }

        if (changed) TabalugaConfig.save();
        return changed || super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean inRow(double mx, double my, int x, int y) {
        return mx >= x && mx <= x + 230 && my >= y - 4 && my <= y + 16;
    }

    private static String cycle(String[] values, String current) {
        int index = 0;
        for (int i = 0; i < values.length; i++) if (values[i].equals(current)) index = i;
        return values[(index + 1) % values.length];
    }

    @Override
    public boolean shouldPause() { return false; }
}
