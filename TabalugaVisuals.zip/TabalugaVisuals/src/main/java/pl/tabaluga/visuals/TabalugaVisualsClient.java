package pl.tabaluga.visuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class TabalugaVisualsClient implements ClientModInitializer {
    public static final String MOD_NAME = "TabalugaVisuals";
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        TabalugaConfig.load();
        CombatVisuals.register();
        TabalugaHud.register();
        // In Minecraft 1.21.4 Yarn, keybinding categories are supplied as translation keys.
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tabalugavisuals.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.misc"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new TabalugaClickGui());
            }
        });
    }
}
