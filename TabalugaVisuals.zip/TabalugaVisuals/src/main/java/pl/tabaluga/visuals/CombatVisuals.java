package pl.tabaluga.visuals;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Cosmetic-only combat feedback. It does not change damage or combat mechanics. */
public final class CombatVisuals {
    private static final Map<UUID, TrackedTarget> TARGETS = new HashMap<>();
    private static LivingEntity currentTarget;
    private static float lastDamage;
    private static int hitMarkerTicks;
    private static int damageTicks;
    private static int combo;
    private static int comboTimer;

    public static LivingEntity getCurrentTarget() { return currentTarget; }
    public static float getLastDamage() { return lastDamage; }
    public static int getHitMarkerTicks() { return hitMarkerTicks; }
    public static int getDamageTicks() { return damageTicks; }
    public static int getCombo() { return combo; }

    private CombatVisuals() {}

    public static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient() || !(entity instanceof LivingEntity living)) return ActionResult.PASS;
            TARGETS.put(living.getUuid(), new TrackedTarget(living, living.getHealth(), 0));
            currentTarget = living;
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
    }

    private static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            TARGETS.clear();
            return;
        }

        if (hitMarkerTicks > 0) hitMarkerTicks--;
        if (damageTicks > 0) damageTicks--;
        if (comboTimer > 0) comboTimer--;
        else combo = 0;

        Iterator<Map.Entry<UUID, TrackedTarget>> iterator = TARGETS.entrySet().iterator();
        while (iterator.hasNext()) {
            TrackedTarget tracked = iterator.next().getValue();
            LivingEntity target = tracked.entity;
            tracked.age++;

            if (tracked.age > 100 || target.isRemoved()) {
                iterator.remove();
                continue;
            }

            float health = target.getHealth();
            if (health < tracked.lastHealth) {
                float damage = tracked.lastHealth - health;
                lastDamage = damage;
                damageTicks = 35;
                hitMarkerTicks = 8;
                combo++;
                comboTimer = 50;
                currentTarget = target;
                if (TabalugaConfig.get().hitParticles) spawnHitParticles(client, target);
            }

            if (TabalugaConfig.get().killEffects && (health <= 0.0f || target.isDead())) {
                spawnKillEffect(client, target);
                if (currentTarget == target) currentTarget = null;
                iterator.remove();
                continue;
            }
            tracked.lastHealth = health;
        }
        if (currentTarget != null && (currentTarget.isRemoved() || currentTarget.isDead())) currentTarget = null;
    }

    private static void spawnHitParticles(MinecraftClient client, Entity target) {
        if (client.world == null) return;
        Vec3d pos = target.getPos().add(0, target.getHeight() * 0.55, 0);
        for (int i = 0; i < 7; i++) {
            double ox = (client.world.random.nextDouble() - 0.5) * 0.65;
            double oy = client.world.random.nextDouble() * 0.55;
            double oz = (client.world.random.nextDouble() - 0.5) * 0.65;
            client.world.addParticle(ParticleTypes.CRIT, pos.x + ox, pos.y + oy, pos.z + oz,
                    ox * 0.12, 0.04 + oy * 0.08, oz * 0.12);
        }
    }

    private static void spawnKillEffect(MinecraftClient client, Entity target) {
        if (client.world == null) return;
        ParticleEffect particle = switch (TabalugaConfig.get().killEffect) {
            case "Flame" -> ParticleTypes.FLAME;
            case "Hearts" -> ParticleTypes.HEART;
            case "Soul" -> ParticleTypes.SOUL;
            case "Portal" -> ParticleTypes.PORTAL;
            case "Ice" -> ParticleTypes.SNOWFLAKE;
            case "Totem" -> ParticleTypes.TOTEM_OF_UNDYING;
            case "Galaxy" -> ParticleTypes.END_ROD;
            default -> ParticleTypes.CRIT;
        };

        Vec3d center = target.getPos().add(0, target.getHeight() * 0.5, 0);
        int count = TabalugaConfig.get().performanceMode ? 16 : 30;
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2.0 * i) / count;
            double radius = 0.35 + client.world.random.nextDouble() * 0.45;
            double x = Math.cos(angle) * radius;
            double z = Math.sin(angle) * radius;
            double y = (client.world.random.nextDouble() - 0.35) * 0.9;
            client.world.addParticle(particle, center.x + x, center.y + y, center.z + z,
                    x * 0.08, 0.08 + client.world.random.nextDouble() * 0.08, z * 0.08);
        }
    }

    private static final class TrackedTarget {
        private final LivingEntity entity;
        private float lastHealth;
        private int age;

        private TrackedTarget(LivingEntity entity, float lastHealth, int age) {
            this.entity = entity;
            this.lastHealth = lastHealth;
            this.age = age;
        }
    }
}
