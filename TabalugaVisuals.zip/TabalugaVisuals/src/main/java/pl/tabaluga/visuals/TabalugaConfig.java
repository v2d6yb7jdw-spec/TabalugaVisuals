package pl.tabaluga.visuals;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent client-side settings for TabalugaVisuals. */
public final class TabalugaConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("tabalugavisuals.json");
    private static TabalugaConfig INSTANCE = new TabalugaConfig();

    public boolean showWatermark = true;
    public boolean performanceMode = true;
    public boolean hitParticles = true;
    public boolean killEffects = true;
    public String killEffect = "Galaxy";
    public String accentColor = "A66BFF";
    public boolean hitMarker = true;
    public boolean damageNumbers = true;
    public boolean comboCounter = true;
    public boolean targetHud = true;
    public boolean cooldownRing = true;
    public boolean customCrosshair = true;
    public String crosshairStyle = "Plus";
    public int crosshairSize = 7;
    public int crosshairGap = 3;
    /** Changes the custom crosshair from white to red while targeting a living entity. */
    public boolean crosshairTargetColor = true;
    public String activePreset = "Default";

    private TabalugaConfig() { }

    public static TabalugaConfig get() { return INSTANCE; }

    public static void load() {
        if (Files.exists(FILE)) {
            try {
                TabalugaConfig loaded = GSON.fromJson(Files.readString(FILE), TabalugaConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                    if (INSTANCE.killEffect == null) INSTANCE.killEffect = "Galaxy";
                    if (INSTANCE.crosshairStyle == null) INSTANCE.crosshairStyle = "Plus";
                    if (INSTANCE.activePreset == null) INSTANCE.activePreset = "Default";
                }
            } catch (Exception exception) {
                System.err.println("[TabalugaVisuals] Config reset: " + exception.getMessage());
                INSTANCE = new TabalugaConfig();
            }
        }
        save();
    }

    public static void applyPreset(String preset) {
        TabalugaConfig c = get();
        c.activePreset = preset;
        switch (preset) {
            case "PvP" -> {
                c.showWatermark = true; c.performanceMode = true; c.hitParticles = true;
                c.killEffects = true; c.hitMarker = true; c.damageNumbers = true;
                c.comboCounter = true; c.targetHud = true; c.cooldownRing = true;
                c.customCrosshair = true; c.crosshairTargetColor = true;
            }
            case "Minimal" -> {
                c.showWatermark = true; c.performanceMode = true; c.hitParticles = false;
                c.killEffects = false; c.hitMarker = false; c.damageNumbers = false;
                c.comboCounter = false; c.targetHud = false; c.cooldownRing = false;
                c.customCrosshair = true; c.crosshairTargetColor = false;
            }
            default -> {
                c.showWatermark = true; c.performanceMode = true; c.hitParticles = true;
                c.killEffects = true; c.hitMarker = true; c.damageNumbers = true;
                c.comboCounter = true; c.targetHud = true; c.cooldownRing = true;
                c.customCrosshair = true; c.crosshairTargetColor = true;
            }
        }
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(INSTANCE));
        } catch (IOException exception) {
            System.err.println("[TabalugaVisuals] Could not save config: " + exception.getMessage());
        }
    }
}
