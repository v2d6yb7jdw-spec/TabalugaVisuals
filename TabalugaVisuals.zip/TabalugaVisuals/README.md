# TabalugaVisuals 0.1 — projekt Fabric

Projekt startowy moda klienckiego dla Minecraft Java 1.21.4, Fabric, Java 21.

## Budowanie na Windows
1. Zainstaluj JDK 21 (nie samo JRE).
2. Otwórz folder projektu.
3. Kliknij pasek adresu Eksploratora, wpisz `cmd` i naciśnij Enter.
4. Uruchom: `gradlew.bat build`
5. Gotowy plik JAR będzie w `build/libs/`.

## Budowanie na Linux/macOS
W terminalu w folderze projektu uruchom: `./gradlew build`.

Skrypt `gradlew` / `gradlew.bat` pobiera Gradle 8.10.2 przy pierwszym uruchomieniu. Gradle pobierze również wymagane biblioteki projektu, więc potrzebne jest połączenie z internetem.

## Ważne
To wczesny szkielet projektu 0.1, a nie komplet funkcji z pełnej listy. Kompilację i działanie w Minecraft 1.21.4 (w tym zgodność z Sodium) trzeba potwierdzić testem w grze. Nie instaluj JAR-a, dopóki kompilacja nie zakończy się poprawnie.
